⚠️ Important 
This project is no longer being continued, maybe someday there will be a new project with command templates in it

https://github.com/miruchigawa/Template-Bot-Facebook

Hello, this is my project for this time I'm making a Facebook bot with OpenAi inside it, this is a simple coding and maybe not so neat inside.

I'll just explain some of the functions and uses of this bot.

First, let's setup the config file. Go to session.json, we need a Facebook cookie to get it, we need to login to Facebook and use a cookie editor extension or use developer mode.

Next, in the api_key.json, we need an OpenAi API Key, to get it, go to the official website.

Once that's done, let's move on to the second step. Open the terminal, type in the command npm install, once that's done, type in the command node index.js to start the bot.

You can edit or change the owner.

If you have any questions, feel free to send them to:
Twitter: https://twitter.com/miruchigawa
Facebook: https://www.facebook.com/kritoz.ae
Website: https://miftahfauzan.netlify.app
